package br.com.lanchonetegui;

public interface InterfaceLanchonete {

	public double calcularValor();
	public String identificarPedido();
}
